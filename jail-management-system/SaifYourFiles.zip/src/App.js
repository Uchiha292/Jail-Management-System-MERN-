import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Container, CssBaseline } from "@mui/material"; // Import MUI components
import Navbar from "./components/Navbar";
import Signup from "./components/Auth/Signup";
import Login from "./components/Auth/Login";
import Guidelines from "./pages/Guidelines";
import GoogleSignIn from "./components/Auth/GoogleSignIn";

const App = () => {
  return (
    <>
      <CssBaseline /> {/* Resets some default styles and ensures consistency */}
      <Router>
        <Navbar />
        <Container maxWidth="md"> {/* Center content with margin */}
          <Routes>
            <Route path="/signup" element={<Signup />} />
            <Route path="/login" element={<Login />} />
            <Route path="/guidelines" element={<Guidelines />} />
            <Route path="/google-signin" element={<GoogleSignIn />} />
          </Routes>
        </Container>
      </Router>
    </>
  );
};

export default App;
