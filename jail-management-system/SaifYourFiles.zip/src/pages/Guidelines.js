import React from "react";
import { Typography, Box } from "@mui/material";

const Guidelines = () => {
  return (
    <Box sx={{ padding: 2 }}>
      <Typography variant="h4" gutterBottom>
        Prison Visitation Guidelines
      </Typography>
      <Typography variant="body1" paragraph>
        {/* Add your guidelines text here */}
        1. All visitors must be approved.
        2. Visitation hours are from 9 AM to 5 PM.
        3. No electronic devices allowed inside the facility.
        {/* Continue with the rest of the guidelines */}
      </Typography>
    </Box>
  );
};

export default Guidelines;
