import React from "react";
import { GoogleLogin } from "@react-oauth/google";
import { Box, Typography } from "@mui/material";

const GoogleSignIn = () => {
  const handleLoginSuccess = (response) => {
    console.log("Login Success:", response);
    // Send the token to your backend for further processing (authentication)
  };

  const handleLoginFailure = (error) => {
    console.log("Login Failed:", error);
  };

  return (
    <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", padding: 2 }}>
      <Typography variant="h4" gutterBottom>
        Sign in with Google
      </Typography>
      <GoogleLogin 
        onSuccess={handleLoginSuccess}
        onError={handleLoginFailure}
        useOneTap
      />
    </Box>
  );
};

export default GoogleSignIn;
